package com.testshop.myshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyshopApplicationTests {

    @Test
    void contextLoads() {
    }

}
